import '@testing-library/jest-dom'
import React from 'react'

global.React = React // this also works for other globally available libraries
