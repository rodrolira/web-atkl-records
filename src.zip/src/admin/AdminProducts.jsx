import React from 'react';

function AdminProducts() {
  return (
    <div>
      AdminProducts
    </div>
  );
}

export default AdminProducts;
