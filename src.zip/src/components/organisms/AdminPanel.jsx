import React from 'react'
import { useNavigate } from 'react-router-dom'

function AdminPanel () {
  return <div>AdminPanel</div>
}

export default AdminPanel
