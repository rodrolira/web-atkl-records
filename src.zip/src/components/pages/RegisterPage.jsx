import Navbar from '../organisms/Navbar'
import Register from '../organisms/Register'

function RegisterPage () {
    return (
        <>
            <Navbar />

            <Register />
        </>
    )
}

export default RegisterPage
