import React from 'react'
import { render, screen, fireEvent, waitFor } from '@testing-library/react'
import jest from 'jest'
import AddArtistForm from './AddArtistForm'
import { useTranslation } from 'react-i18next'
import { useArtists } from '../../../contexts/ArtistContext'

// Mock de useTranslation
jest.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: (key) => key,
    }),
}))

// Mock de useArtists
jest.mock('../../../contexts/ArtistContext', () => ({
    useArtists: () => ({
        createArtist: jest.fn(),
    }),
}))

describe('AddArtistForm', () => {
    it('renders the form', () => {
        render(<AddArtistForm />)
        expect(screen.getByText('addArtist.title')).toBeInTheDocument()
    })

    it('opens and closes the dialog', () => {
        render(<AddArtistForm />)
        fireEvent.click(screen.getByText('addArtist.title'))
        expect(screen.getByText('addArtist.title')).toBeInTheDocument()
        fireEvent.click(screen.getByRole('button', { name: /close/i }))
        expect(screen.queryByText('addArtist.title')).not.toBeInTheDocument()
    })

    it('validates the form fields', async () => {
        render(<AddArtistForm />)
        fireEvent.click(screen.getByText('addArtist.title'))
        fireEvent.click(screen.getByText('submit'))
        await waitFor(() => {
            expect(screen.getByText('addArtist.validation.artistNameRequired')).toBeInTheDocument()
            expect(screen.getByText('addArtist.validation.usernameRequired')).toBeInTheDocument()
            expect(screen.getByText('addArtist.validation.emailRequired')).toBeInTheDocument()
            expect(screen.getByText('addArtist.validation.passwordRequired')).toBeInTheDocument()
        })
    })

    it('calls createArtist on form submission', async () => {
        const createArtistMock = jest.fn()
        useArtists.mockReturnValue({ createArtist: createArtistMock })

        render(<AddArtistForm />)
        fireEvent.click(screen.getByText('addArtist.title'))

        fireEvent.change(screen.getByLabelText('artist_name'), { target: { value: 'Test Artist' } })
        fireEvent.change(screen.getByLabelText('username'), { target: { value: 'testuser' } })
        fireEvent.change(screen.getByLabelText('email'), { target: { value: 'test@example.com' } })
        fireEvent.change(screen.getByLabelText('password'), { target: { value: 'password123' } })

        fireEvent.click(screen.getByText('submit'))

        await waitFor(() => {
            expect(createArtistMock).toHaveBeenCalled()
        })
    })
})
