import Login from '../organisms/Login'
import Navbar from '../organisms/Navbar'
function LoginArtistPage() {
  return (
    <div>
      <Navbar />
      <Login />

    </div>
  )
}

export default LoginArtistPage
